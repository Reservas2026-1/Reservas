import React, { createContext, useContext, useState, useEffect } from 'react'

export interface ColorPalette {
  id: string
  name: string
  primaryHex: string
  bgClass: string
  textClass: string
  borderClass: string
  ringClass: string
  fromClass: string
  toClass: string
}

export const PALETTES: ColorPalette[] = [
  {
    id: 'red-cycle',
    name: 'Rojo Pasión (Por Defecto)',
    primaryHex: '#DC2626',
    bgClass: 'bg-red-600',
    textClass: 'text-red-600',
    borderClass: 'border-red-600',
    ringClass: 'ring-red-600',
    fromClass: 'from-red-600',
    toClass: 'to-rose-700',
  },
  {
    id: 'blue-nitro',
    name: 'Azul Eléctrico',
    primaryHex: '#2563EB',
    bgClass: 'bg-blue-600',
    textClass: 'text-blue-600',
    borderClass: 'border-blue-600',
    ringClass: 'ring-blue-600',
    fromClass: 'from-blue-600',
    toClass: 'to-indigo-700',
  },
  {
    id: 'emerald-neon',
    name: 'Verde Neón',
    primaryHex: '#059669',
    bgClass: 'bg-emerald-600',
    textClass: 'text-emerald-600',
    borderClass: 'border-emerald-600',
    ringClass: 'ring-emerald-600',
    fromClass: 'from-emerald-600',
    toClass: 'to-teal-700',
  },
  {
    id: 'purple-flow',
    name: 'Púrpura Flow',
    primaryHex: '#7C3AED',
    bgClass: 'bg-purple-600',
    textClass: 'text-purple-600',
    borderClass: 'border-purple-600',
    ringClass: 'ring-purple-600',
    fromClass: 'from-purple-600',
    toClass: 'to-fuchsia-700',
  },
  {
    id: 'amber-boost',
    name: 'Naranja Boost',
    primaryHex: '#EA580C',
    bgClass: 'bg-orange-600',
    textClass: 'text-orange-600',
    borderClass: 'border-orange-600',
    ringClass: 'ring-orange-600',
    fromClass: 'from-orange-600',
    toClass: 'to-amber-700',
  },
]

interface BrandingContextType {
  studioName: string
  setStudioName: (name: string) => void
  currentPalette: ColorPalette
  setPaletteById: (id: string) => void
  isDarkMode: boolean
  toggleDarkMode: () => void
  empresaId: string
  setEmpresaId: (id: string) => void
}

const BrandingContext = createContext<BrandingContextType | undefined>(undefined)

export const BrandingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [studioName, setStudioName] = useState('VELO-X Cycling Studio')
  const [paletteId, setPaletteId] = useState('red-cycle')
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [empresaId, setEmpresaId] = useState('emp-velo-001')

  const currentPalette = PALETTES.find((p) => p.id === paletteId) || PALETTES[0]

  useEffect(() => {
    // Aplicar clase .dark al elemento <html>
    const root = document.documentElement
    if (isDarkMode) {
      root.classList.add('dark')
    } else {
      root.classList.remove('dark')
    }
  }, [isDarkMode])

  const toggleDarkMode = () => setIsDarkMode((prev) => !prev)
  const setPaletteById = (id: string) => setPaletteId(id)

  return (
    <BrandingContext.Provider
      value={{
        studioName,
        setStudioName,
        currentPalette,
        setPaletteById,
        isDarkMode,
        toggleDarkMode,
        empresaId,
        setEmpresaId,
      }}
    >
      {children}
    </BrandingContext.Provider>
  )
}

export const useBranding = () => {
  const context = useContext(BrandingContext)
  if (!context) {
    throw new Error('useBranding debe usarse dentro de un BrandingProvider')
  }
  return context
}
