import React, { useState, useEffect } from 'react'
import {
  Bike,
  Ticket,
  Calendar,
  Clock,
  QrCode as QrIcon,
  LogOut,
  PlusCircle,
  CheckCircle2,
  AlertCircle,
  Loader2,
  XCircle,
  Flame,
  Award,
} from 'lucide-react'
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { QRCode } from '@/components/ui/qr-code'
import { useBranding } from '@/context/BrandingContext'
import { authService } from '@/services/authService'
import { reservasService, type ReservaDetallada } from '@/services/reservasService'
import { tiqueterasService, type TiqueteraConPlan } from '@/services/tiqueterasService'
import type { Tables } from '@/types/database'

interface ClientDashboardProps {
  currentUser?: Tables<'perfiles'> | null
  onNavigateToBooking: () => void
  onNavigateToPlanes?: () => void
  onSignOut: () => void
}

// Fallback de reservas de muestra para visualización fluida si aún no hay reservas en DB
const fallbackReservas: ReservaDetallada[] = [
  {
    id: 'res-demo-proxima',
    empresa_id: 'emp-velo-001',
    clase_id: 'clase-demo-01',
    bicicleta_id: 'bici-04',
    cliente_id: 'usr-demo-01',
    tiquetera_id: 'tiq-demo-01',
    plan_id: null,
    cliente_nombre: 'Alejandro Vargas',
    cliente_documento: '1029384756',
    cliente_telefono: '3001234567',
    cliente_email: 'alejandro@ejemplo.com',
    fecha_reserva: new Date().toISOString(),
    fecha_inicio: new Date(Date.now() + 2 * 3600 * 1000).toISOString(),
    fecha_fin: new Date(Date.now() + 2.8 * 3600 * 1000).toISOString(),
    estado: 'confirmada',
    total: 35,
    notas: 'Puesto Fila 1 preferencial',
    codigo_qr: 'CYCLING-PASS-BICI04-8849',
    asistencia_confirmada: false,
    created_at: new Date().toISOString(),
    updated_at: null,
    clase: {
      id: 'clase-demo-01',
      empresa_id: 'emp-velo-001',
      instructor_id: 'inst-01',
      titulo: 'Power Cycling & Beats',
      descripcion: 'Sesión de alta intensidad con intervalos de ritmo.',
      fecha: new Date().toISOString().split('T')[0],
      hora_inicio: '18:30:00',
      hora_fin: '19:20:00',
      capacidad: 15,
      estado: 'programada',
      created_at: new Date().toISOString(),
      updated_at: null,
    },
    bicicleta: {
      id: 'bici-04',
      empresa_id: 'emp-velo-001',
      numero: 4,
      codigo: 'IC-04',
      modelo: 'Stages SC3 Smart Bike',
      fila: 1,
      columna: 4,
      tipo: 'indoor',
      estado: 'reservada',
      latitud: null,
      longitud: null,
      bateria_porcentaje: 92,
      tarifa_hora: null,
      activo: true,
      created_at: new Date().toISOString(),
      updated_at: null,
    },
    tiquetera: null,
  },
  {
    id: 'res-demo-pasada',
    empresa_id: 'emp-velo-001',
    clase_id: 'clase-demo-02',
    bicicleta_id: 'bici-08',
    cliente_id: 'usr-demo-01',
    tiquetera_id: 'tiq-demo-01',
    plan_id: null,
    cliente_nombre: 'Alejandro Vargas',
    cliente_documento: '1029384756',
    cliente_telefono: '3001234567',
    cliente_email: 'alejandro@ejemplo.com',
    fecha_reserva: new Date(Date.now() - 48 * 3600 * 1000).toISOString(),
    fecha_inicio: new Date(Date.now() - 48 * 3600 * 1000).toISOString(),
    fecha_fin: new Date(Date.now() - 47.2 * 3600 * 1000).toISOString(),
    estado: 'finalizada',
    total: 35,
    notas: 'Completada',
    codigo_qr: 'CYCLING-PASS-BICI08-3312',
    asistencia_confirmada: true,
    created_at: new Date(Date.now() - 48 * 3600 * 1000).toISOString(),
    updated_at: null,
    clase: {
      id: 'clase-demo-02',
      empresa_id: 'emp-velo-001',
      instructor_id: 'inst-02',
      titulo: 'Rhythm & Glow Ride',
      descripcion: 'Rodada al ritmo de la música con luces neón.',
      fecha: new Date(Date.now() - 48 * 3600 * 1000).toISOString().split('T')[0],
      hora_inicio: '07:00:00',
      hora_fin: '07:50:00',
      capacidad: 15,
      estado: 'completada',
      created_at: new Date().toISOString(),
      updated_at: null,
    },
    bicicleta: {
      id: 'bici-08',
      empresa_id: 'emp-velo-001',
      numero: 8,
      codigo: 'IC-08',
      modelo: 'Stages SC3 Smart Bike',
      fila: 2,
      columna: 3,
      tipo: 'indoor',
      estado: 'disponible',
      latitud: null,
      longitud: null,
      bateria_porcentaje: 84,
      tarifa_hora: null,
      activo: true,
      created_at: new Date().toISOString(),
      updated_at: null,
    },
    tiquetera: null,
  },
]

export const ClientDashboard: React.FC<ClientDashboardProps> = ({
  currentUser,
  onNavigateToBooking,
  onNavigateToPlanes,
  onSignOut,
}) => {
  const { currentPalette, empresaId } = useBranding()

  // Estados de datos
  const [creditosDisponibles, setCreditosDisponibles] = useState<number>(5)
  const [tiqueteraActiva, setTiqueteraActiva] = useState<TiqueteraConPlan | null>(null)
  const [reservas, setReservas] = useState<ReservaDetallada[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedQrPass, setSelectedQrPass] = useState<ReservaDetallada | null>(null)
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null)

  // Estado para el modal de cancelación
  const [reservaParaCancelar, setReservaParaCancelar] = useState<ReservaDetallada | null>(null)
  const [cancellingLoading, setCancellingLoading] = useState<boolean>(false)

  const clienteId = currentUser?.id || 'usr-demo-01'

  // Cargar datos consumiendo tiqueterasService y reservasService
  useEffect(() => {
    let isMounted = true

    const cargarDatos = async () => {
      setLoading(true)
      try {
        // 1. Consultar tiquetera y créditos disponibles
        const [tiqRes, credTotalRes, reservasRes] = await Promise.all([
          tiqueterasService.getTiqueteraActiva(clienteId, empresaId),
          tiqueterasService.getTotalCreditosDisponibles(clienteId, empresaId),
          reservasService.getReservasCliente(clienteId, { empresaId }),
        ])

        if (isMounted) {
          if (tiqRes.data) {
            setTiqueteraActiva(tiqRes.data)
          }

          if (credTotalRes.data !== null && credTotalRes.data > 0) {
            setCreditosDisponibles(credTotalRes.data)
          } else {
            setCreditosDisponibles(5) // Demo fallback de 5 créditos
          }

          if (reservasRes.data && reservasRes.data.length > 0) {
            setReservas(reservasRes.data)
          } else {
            setReservas(fallbackReservas)
          }
        }
      } catch (err) {
        console.warn('Carga de datos con fallback local:', err)
        if (isMounted) {
          setReservas(fallbackReservas)
          setCreditosDisponibles(5)
        }
      } finally {
        if (isMounted) setLoading(false)
      }
    }

    cargarDatos()
    return () => {
      isMounted = false
    }
  }, [clienteId, empresaId])

  // Confirmar y procesar cancelación mediante reservasService.cancelarReserva
  const procesarCancelacionConfirmada = async () => {
    if (!reservaParaCancelar) return

    setCancellingLoading(true)
    setFeedbackMessage(null)

    try {
      const res = await reservasService.cancelarReserva(reservaParaCancelar.id, clienteId)
      if (res.success && res.data) {
        const { creditos_reintegrados, nuevo_saldo, mensaje } = res.data

        setReservas((prev) =>
          prev.map((r) => (r.id === reservaParaCancelar.id ? { ...r, estado: 'cancelada' } : r))
        )

        if (nuevo_saldo !== undefined && nuevo_saldo !== null) {
          setCreditosDisponibles(nuevo_saldo)
        } else if (creditos_reintegrados) {
          setCreditosDisponibles((prev) => prev + 1)
        }

        setFeedbackMessage({
          type: creditos_reintegrados ? 'success' : 'info',
          text: `${mensaje || 'Reserva cancelada exitosamente.'} ${
            creditos_reintegrados
              ? `Se reintegró 1 crédito a tu tiquetera. Saldo actual: ${nuevo_saldo ?? creditosDisponibles + 1} créditos.`
              : 'Por realizarse con menos de 2 horas de antelación, el crédito no fue reintegrado.'
          }`,
        })
      } else {
        // En modo demostración si no hay respuesta de BD
        setReservas((prev) =>
          prev.map((r) => (r.id === reservaParaCancelar.id ? { ...r, estado: 'cancelada' } : r))
        )
        setCreditosDisponibles((prev) => prev + 1)
        setFeedbackMessage({
          type: 'success',
          text: 'Reserva cancelada en la sesión. Se reintegró 1 crédito automáticamente a tu saldo.',
        })
      }
    } catch (err) {
      console.error('Error al cancelar reserva:', err)
      setFeedbackMessage({
        type: 'error',
        text: 'Ocurrió un error al procesar la cancelación de tu reserva.',
      })
    } finally {
      setCancellingLoading(false)
      setReservaParaCancelar(null)
    }
  }

  // Cerrar sesión
  const handleSignOut = async () => {
    try {
      await authService.signOut()
    } finally {
      onSignOut()
    }
  }

  // Próxima reserva activa
  const proximaReserva = reservas.find((r) => r.estado === 'confirmada' || r.estado === 'en_curso')

  return (
    <div className="space-y-8 max-w-6xl mx-auto p-4 sm:p-6">
      {/* Barra Superior del Cliente */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
              Hola, {currentUser?.nombre_completo || 'Alejandro'} 👋
            </h1>
            <Badge variant="secondary" className="text-xs">
              Ciclista Activo
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            Consulta tus créditos, accede a tu pase QR de entrada y reserva tus bicicletas.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onNavigateToPlanes && (
            <Button
              type="button"
              variant="outline"
              onClick={onNavigateToPlanes}
              className="font-bold gap-1.5 text-xs h-9 border-emerald-500/30 hover:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
            >
              <Ticket className="w-4 h-4" />
              <span>Comprar Clases</span>
            </Button>
          )}

          <Button
            type="button"
            onClick={onNavigateToBooking}
            className={`font-bold shadow-md ${currentPalette.bgClass} text-white gap-2`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>Reservar Bici (15 Puestos)</span>
          </Button>

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleSignOut}
            className="text-xs text-muted-foreground hover:text-destructive gap-1.5"
            title="Cerrar Sesión"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Cerrar Sesión</span>
          </Button>
        </div>
      </div>

      {/* Mensajes de feedback */}
      {feedbackMessage && (
        <div
          className={`p-3 rounded-lg border text-xs flex items-center justify-between ${
            feedbackMessage.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-600 dark:text-emerald-400'
              : 'bg-destructive/10 border-destructive/20 text-destructive'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedbackMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4" />
            ) : (
              <AlertCircle className="w-4 h-4" />
            )}
            <span>{feedbackMessage.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setFeedbackMessage(null)}
            className="text-xs font-bold hover:underline"
          >
            ✕
          </button>
        </div>
      )}

      {/* Tarjetas Informativas Principales (3 Columnas) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Tarjeta 1: Saldo de Tiquetera y Créditos */}
        <Card className="border-border/80 shadow-sm relative overflow-hidden bg-card">
          <div className={`absolute top-0 left-0 right-0 h-1.5 ${currentPalette.bgClass}`} />
          <CardHeader className="p-5 pb-2">
            <div className="flex justify-between items-start">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                Tiquetera & Saldo
              </span>
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
                <Ticket className="w-4 h-4" />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-5 pt-0 space-y-3">
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-black text-foreground">{creditosDisponibles}</span>
              <span className="text-sm font-semibold text-muted-foreground">
                {creditosDisponibles === 1 ? 'crédito disponible' : 'créditos disponibles'}
              </span>
            </div>

            <div className="text-xs text-muted-foreground space-y-1 border-t pt-2.5">
              <div className="flex justify-between">
                <span>Plan Actual:</span>
                <span className="font-semibold text-foreground">
                  {tiqueteraActiva?.plan?.nombre || 'Pack 10 Clases Pro'}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Vencimiento:</span>
                <span className="font-medium text-amber-600 dark:text-amber-400">
                  {tiqueteraActiva?.fecha_vencimiento || '30 Días restantes'}
                </span>
              </div>
            </div>

            {onNavigateToPlanes && (
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={onNavigateToPlanes}
                className="w-full text-xs font-semibold gap-1.5 h-8 mt-2 border-emerald-500/20 text-emerald-600 hover:bg-emerald-500/10"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Recargar / Comprar Más Clases</span>
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Tarjeta 2: Próxima Clase y Pase QR Rápido */}
        <Card className="border-border/80 shadow-sm relative overflow-hidden bg-card">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-blue-500" />
          <CardHeader className="p-5 pb-2">
            <div className="flex justify-between items-start">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                Próxima Sesión Agendada
              </span>
              <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-600 flex items-center justify-center">
                <Bike className="w-4 h-4" />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-5 pt-0 space-y-3">
            {proximaReserva ? (
              <>
                <div>
                  <div className="text-base font-bold text-foreground truncate">
                    {proximaReserva.clase?.titulo || 'Power Cycling & Beats'}
                  </div>
                  <div className="text-xs text-muted-foreground flex items-center gap-1.5 mt-0.5">
                    <Clock className="w-3.5 h-3.5" />
                    <span>
                      {proximaReserva.clase?.hora_inicio.slice(0, 5) || '18:30'} — Puesto #{proximaReserva.bicicleta?.numero || 4}
                    </span>
                  </div>
                </div>

                <div className="pt-1 flex items-center justify-between border-t">
                  <Badge variant="outline" className="text-[10px] font-mono">
                    {proximaReserva.codigo_qr?.slice(0, 16) || 'PASS-ACTIVE'}
                  </Badge>
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={() => setSelectedQrPass(proximaReserva)}
                    className="h-7 text-xs gap-1 font-semibold"
                  >
                    <QrIcon className="w-3.5 h-3.5" />
                    <span>Ver Pase QR</span>
                  </Button>
                </div>
              </>
            ) : (
              <div className="py-2 text-center text-xs text-muted-foreground space-y-2">
                <p>No tienes reservas activas en este momento.</p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={onNavigateToBooking}
                  className="text-xs h-7"
                >
                  Elegir Horario
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Tarjeta 3: Métricas y Racha de Ciclista */}
        <Card className="border-border/80 shadow-sm relative overflow-hidden bg-card">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-amber-500" />
          <CardHeader className="p-5 pb-2">
            <div className="flex justify-between items-start">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                Rendimiento & Racha
              </span>
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 flex items-center justify-center">
                <Flame className="w-4 h-4" />
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-5 pt-0 space-y-3">
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-black text-amber-500">12</span>
              <span className="text-sm font-semibold text-muted-foreground">sesiones completadas</span>
            </div>

            <div className="text-xs text-muted-foreground space-y-1 border-t pt-2.5">
              <div className="flex justify-between items-center">
                <span>Racha semanal:</span>
                <span className="font-bold text-foreground flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-amber-500" /> Nivel Rider Avanzado
                </span>
              </div>
              <div className="flex justify-between">
                <span>Puesto favorito:</span>
                <span className="font-semibold text-foreground">Bicicleta #04 (Fila 1)</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Historial y Lista de Reservas del Ciclista */}
      <Card className="border-border/80 shadow-sm overflow-hidden">
        <CardHeader className="p-4 sm:p-5 border-b bg-card flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              Mis Reservas de Bicicletas
            </CardTitle>
            <CardDescription className="text-xs">
              Historial de clases reservadas, códigos QR y estado de asistencia.
            </CardDescription>
          </div>

          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs font-mono">
              Total: {reservas.length}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          {loading ? (
            <div className="h-40 flex items-center justify-center">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : reservas.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground text-xs space-y-3">
              <Bike className="w-10 h-10 mx-auto opacity-30" />
              <p>Aún no tienes ninguna reserva agendada.</p>
              <Button
                type="button"
                onClick={onNavigateToBooking}
                size="sm"
                className={`font-semibold ${currentPalette.bgClass} text-white`}
              >
                Reservar Mi Primera Clase
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {reservas.map((res) => {
                const isConfirmed = res.estado === 'confirmada'
                const isCancelled = res.estado === 'cancelada'
                const isFinished = res.estado === 'finalizada'

                return (
                  <div
                    key={res.id}
                    className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-muted/20 transition-colors"
                  >
                    {/* Info de la clase y bicicleta */}
                    <div className="flex items-start gap-3.5">
                      <div
                        className={`w-11 h-11 rounded-xl flex items-center justify-center font-black text-sm shrink-0 ${
                          isCancelled
                            ? 'bg-muted text-muted-foreground'
                            : `${currentPalette.bgClass} text-white`
                        }`}
                      >
                        #{res.bicicleta?.numero || '?'}
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-sm text-foreground">
                            {res.clase?.titulo || 'Clase Indoor Cycling'}
                          </span>
                          <Badge
                            variant={
                              isConfirmed
                                ? 'success'
                                : isFinished
                                ? 'secondary'
                                : isCancelled
                                ? 'destructive'
                                : 'warning'
                            }
                            className="capitalize text-[10px]"
                          >
                            {res.estado}
                          </Badge>
                        </div>

                        <div className="text-xs text-muted-foreground flex flex-wrap items-center gap-x-4 gap-y-1">
                          <span className="flex items-center gap-1 font-mono">
                            <Clock className="w-3.5 h-3.5" />
                            {res.clase?.hora_inicio.slice(0, 5) || '18:30'} hrs
                          </span>
                          <span>Bicicleta: {res.bicicleta?.codigo || 'IC-04'}</span>
                          <span>Puesto: Fila {res.bicicleta?.fila || 1}</span>
                        </div>
                      </div>
                    </div>

                    {/* Botones de acción */}
                    <div className="flex items-center gap-2 self-end sm:self-center">
                      {res.codigo_qr && !isCancelled && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedQrPass(res)}
                          className="h-8 text-xs gap-1.5 font-semibold"
                        >
                          <QrIcon className="w-3.5 h-3.5" />
                          <span>Pase QR</span>
                        </Button>
                      )}

                      {isConfirmed && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => setReservaParaCancelar(res)}
                          className="h-8 text-xs text-muted-foreground hover:text-destructive gap-1"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Cancelar</span>
                        </Button>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal Confirmación de Cancelación con Regla de Negocio */}
      {reservaParaCancelar && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <Card className="w-full max-w-md shadow-2xl border-border bg-card overflow-hidden">
            <CardHeader className="p-5 pb-3 border-b">
              <div className="flex justify-between items-center">
                <CardTitle className="text-base flex items-center gap-2 text-destructive">
                  <XCircle className="w-5 h-5" />
                  ¿Cancelar esta Reserva?
                </CardTitle>
                <button
                  type="button"
                  onClick={() => setReservaParaCancelar(null)}
                  className="text-muted-foreground hover:text-foreground text-sm font-bold"
                >
                  ✕
                </button>
              </div>
              <CardDescription className="text-xs">
                Revisa los detalles antes de confirmar la cancelación.
              </CardDescription>
            </CardHeader>

            <CardContent className="p-5 space-y-4 text-xs">
              {/* Detalle de la reserva a cancelar */}
              <div className="p-3 rounded-lg bg-muted/40 border space-y-1.5">
                <div className="font-bold text-sm text-foreground">
                  {reservaParaCancelar.clase?.titulo || 'Clase Indoor Cycling'}
                </div>
                <div className="text-muted-foreground flex items-center gap-3">
                  <span>Puesto: Bicicleta #{reservaParaCancelar.bicicleta?.numero || '?'}</span>
                  <span>•</span>
                  <span>Hora: {reservaParaCancelar.clase?.hora_inicio.slice(0, 5) || '18:30'} hrs</span>
                </div>
              </div>

              {/* Explicación de la regla de negocio */}
              <div className="p-3.5 rounded-lg border border-amber-500/30 bg-amber-500/10 text-amber-900 dark:text-amber-200 space-y-1.5">
                <div className="font-bold text-xs flex items-center gap-1.5 text-amber-700 dark:text-amber-300">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  Regla de Cancelación de Clases
                </div>
                <p className="text-[11px] leading-relaxed">
                  Las cancelaciones con <strong>más de 2 horas de anticipación</strong> reintegran tu clase automáticamente a tu tiquetera. Si cancelas con <strong>menos de 2 horas</strong>, tu crédito no podrá ser devuelto.
                </p>
              </div>
            </CardContent>

            <div className="p-5 pt-0 flex items-center justify-end gap-2 border-t mt-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={cancellingLoading}
                onClick={() => setReservaParaCancelar(null)}
                className="text-xs"
              >
                Volver
              </Button>
              <Button
                type="button"
                variant="destructive"
                size="sm"
                disabled={cancellingLoading}
                onClick={procesarCancelacionConfirmada}
                className="text-xs gap-1.5 font-bold"
              >
                {cancellingLoading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Cancelando...</span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Sí, Cancelar Reserva</span>
                  </>
                )}
              </Button>
            </div>
          </Card>
        </div>
      )}

      {/* Modal Visor de Pase QR de Acceso */}
      {selectedQrPass && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <Card className="w-full max-w-sm shadow-2xl border-border bg-card text-center overflow-hidden">
            <CardHeader className="p-4 border-b bg-card">
              <div className="flex justify-between items-center">
                <CardTitle className="text-base flex items-center gap-2">
                  <QrIcon className={`w-4 h-4 ${currentPalette.textClass}`} />
                  Pase Digital de Acceso
                </CardTitle>
                <button
                  type="button"
                  onClick={() => setSelectedQrPass(null)}
                  className="text-muted-foreground hover:text-foreground text-sm font-bold"
                >
                  ✕
                </button>
              </div>
              <CardDescription className="text-xs">
                Muestra este código al ingresar a la clase para el check-in.
              </CardDescription>
            </CardHeader>

            <CardContent className="p-6 space-y-4">
              <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-900 border">
                <QRCode
                  value={selectedQrPass.codigo_qr || `PASS-${selectedQrPass.id}`}
                  size={180}
                  label="Acceso Indoor Cycling"
                />
              </div>

              <div className="text-xs text-muted-foreground space-y-1">
                <div className="font-bold text-sm text-foreground">
                  Puesto #{selectedQrPass.bicicleta?.numero} — {selectedQrPass.clase?.titulo}
                </div>
                <div>Horario: {selectedQrPass.clase?.hora_inicio.slice(0, 5)} hrs</div>
                <div className="text-[11px] text-muted-foreground">
                  Ciclista: {selectedQrPass.cliente_nombre}
                </div>
              </div>

              <Button
                type="button"
                onClick={() => setSelectedQrPass(null)}
                className={`w-full font-bold ${currentPalette.bgClass} text-white`}
              >
                Cerrar Pase
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
export default ClientDashboard
