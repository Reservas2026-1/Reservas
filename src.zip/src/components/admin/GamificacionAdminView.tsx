import React, { useState, useEffect, useCallback, useMemo } from 'react'
import {
  Trophy,
  Sparkles,
  Zap,
  Award,
  PlusCircle,
  Pencil,
  Trash2,
  Loader2,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Search,
  TrendingUp,
  Flame,
  Calendar,
  Gift,
  ShieldAlert,
} from 'lucide-react'
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { toast } from '@/components/ui/use-toast'
import { useBranding, getConfiguracionVertical } from '@/context/BrandingContext'
import {
  gamificacionService,
  type AlumnoGamificacionResumen,
} from '@/services/gamificacionService'
import type { ReglasXpRow } from '@/types/database'

export const GamificacionAdminView: React.FC = () => {
  const { currentPalette, empresaId, studioName, estudioActivo } = useBranding()
  const verticalConfig = getConfiguracionVertical(estudioActivo?.tipo_negocio)

  // Estados Sección 1: Reglas XP
  const [reglas, setReglas] = useState<ReglasXpRow[]>([])
  const [loadingReglas, setLoadingReglas] = useState<boolean>(true)
  const [togglingReglaId, setTogglingReglaId] = useState<string | null>(null)

  // Modal Regla XP (Crear/Editar)
  const [modalReglaOpen, setModalReglaOpen] = useState<boolean>(false)
  const [editingRegla, setEditingRegla] = useState<ReglasXpRow | null>(null)
  const [guardandoRegla, setGuardandoRegla] = useState<boolean>(false)
  const [formRegla, setFormRegla] = useState({
    criterio: '',
    puntosXp: '100',
    descripcion: '',
    activo: true,
  })

  // Modal Confirmación Eliminar Regla
  const [deletingRegla, setDeletingRegla] = useState<ReglasXpRow | null>(null)
  const [eliminandoRegla, setEliminandoRegla] = useState<boolean>(false)

  // Estados Sección 2: Ranking y Progreso de Alumnos
  const [alumnos, setAlumnos] = useState<AlumnoGamificacionResumen[]>([])
  const [loadingAlumnos, setLoadingAlumnos] = useState<boolean>(true)
  const [busquedaAlumno, setBusquedaAlumno] = useState<string>('')
  const [filtroPlanCumplido, setFiltroPlanCumplido] = useState<'todos' | 'cumplido' | 'en_progreso'>('todos')

  // Cargar Reglas XP
  const cargarReglas = useCallback(async () => {
    setLoadingReglas(true)
    try {
      const res = await gamificacionService.obtenerReglasXP(empresaId)
      if (res.error) {
        toast({
          variant: 'destructive',
          title: 'Error al cargar reglas XP',
          description: res.error,
        })
      } else {
        setReglas(res.data || [])
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Error al consultar reglas'
      toast({ variant: 'destructive', title: 'Error', description: msg })
    } finally {
      setLoadingReglas(false)
    }
  }, [empresaId])

  // Cargar Progreso de Alumnos
  const cargarAlumnos = useCallback(async () => {
    setLoadingAlumnos(true)
    try {
      const res = await gamificacionService.obtenerResumenGamificacionEmpresa(empresaId)
      if (res.error) {
        toast({
          variant: 'destructive',
          title: 'Error al cargar alumnos',
          description: res.error,
        })
      } else {
        setAlumnos(res.data || [])
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Error al consultar alumnos'
      toast({ variant: 'destructive', title: 'Error', description: msg })
    } finally {
      setLoadingAlumnos(false)
    }
  }, [empresaId])

  useEffect(() => {
    cargarReglas()
    cargarAlumnos()
  }, [cargarReglas, cargarAlumnos])

  // Handlers Reglas
  const handleOpenCrearRegla = () => {
    setEditingRegla(null)
    setFormRegla({
      criterio: '',
      puntosXp: '100',
      descripcion: '',
      activo: true,
    })
    setModalReglaOpen(true)
  }

  const handleOpenEditarRegla = (regla: ReglasXpRow) => {
    setEditingRegla(regla)
    setFormRegla({
      criterio: regla.criterio,
      puntosXp: String(regla.puntos_xp),
      descripcion: regla.descripcion || '',
      activo: regla.activo,
    })
    setModalReglaOpen(true)
  }

  const handleGuardarRegla = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formRegla.criterio.trim()) return

    setGuardandoRegla(true)
    try {
      const puntosXp = Math.max(0, Number.parseInt(formRegla.puntosXp, 10) || 0)

      if (editingRegla) {
        const res = await gamificacionService.actualizarReglaXP(editingRegla.id, empresaId, {
          criterio: formRegla.criterio.trim(),
          puntos_xp: puntosXp,
          descripcion: formRegla.descripcion.trim() || null,
          activo: formRegla.activo,
        })

        if (res.error || !res.data) {
          toast({
            variant: 'destructive',
            title: 'No se pudo actualizar la regla',
            description: res.error || 'Error inesperado',
          })
          return
        }

        setReglas((prev) => prev.map((r) => (r.id === editingRegla.id ? res.data! : r)))
        toast({
          variant: 'success',
          title: 'Regla actualizada',
          description: `"${res.data.criterio}" (+${res.data.puntos_xp} XP) guardada.`,
        })
      } else {
        const res = await gamificacionService.crearReglaXP({
          empresaId,
          criterio: formRegla.criterio.trim(),
          puntosXp,
          descripcion: formRegla.descripcion.trim() || undefined,
          activo: formRegla.activo,
        })

        if (res.error || !res.data) {
          toast({
            variant: 'destructive',
            title: 'No se pudo crear la regla',
            description: res.error || 'Error inesperado',
          })
          return
        }

        setReglas((prev) => [res.data!, ...prev])
        toast({
          variant: 'success',
          title: 'Regla XP creada',
          description: `"${res.data.criterio}" agregada exitosamente.`,
        })
      }

      setModalReglaOpen(false)
    } finally {
      setGuardandoRegla(false)
    }
  }

  const handleToggleEstadoRegla = async (regla: ReglasXpRow) => {
    setTogglingReglaId(regla.id)
    try {
      const res = await gamificacionService.cambiarEstadoReglaXP(regla.id, empresaId, !regla.activo)
      if (res.error || !res.data) {
        toast({
          variant: 'destructive',
          title: 'Error cambiando estado',
          description: res.error || 'No se pudo modificar la regla',
        })
        return
      }
      setReglas((prev) => prev.map((r) => (r.id === regla.id ? res.data! : r)))
      toast({
        variant: 'success',
        title: res.data.activo ? 'Regla activada' : 'Regla desactivada',
        description: `"${res.data.criterio}" ahora está ${res.data.activo ? 'activa' : 'inactiva'}.`,
      })
    } finally {
      setTogglingReglaId(null)
    }
  }

  const handleConfirmEliminarRegla = async () => {
    if (!deletingRegla) return
    setEliminandoRegla(true)
    try {
      const res = await gamificacionService.eliminarReglaXP(deletingRegla.id, empresaId)
      if (!res.success) {
        toast({
          variant: 'destructive',
          title: 'No se pudo eliminar la regla',
          description: res.error || 'Error al eliminar',
        })
        return
      }

      setReglas((prev) => prev.filter((r) => r.id !== deletingRegla.id))
      toast({
        variant: 'success',
        title: 'Regla eliminada',
        description: `"${deletingRegla.criterio}" fue retirada del estudio.`,
      })
      setDeletingRegla(null)
    } finally {
      setEliminandoRegla(false)
    }
  }

  // Filtrado de alumnos
  const alumnosFiltrados = useMemo(() => {
    return alumnos.filter((alumno) => {
      const matchBusqueda =
        !busquedaAlumno ||
        alumno.nombre_completo.toLowerCase().includes(busquedaAlumno.toLowerCase()) ||
        alumno.email.toLowerCase().includes(busquedaAlumno.toLowerCase()) ||
        (alumno.documento && alumno.documento.includes(busquedaAlumno))

      const matchPlan =
        filtroPlanCumplido === 'todos' ||
        (filtroPlanCumplido === 'cumplido' && alumno.bono_plan_otorgado) ||
        (filtroPlanCumplido === 'en_progreso' && !alumno.bono_plan_otorgado)

      return matchBusqueda && matchPlan
    })
  }, [alumnos, busquedaAlumno, filtroPlanCumplido])

  // Estadísticas rápidas
  const metricasResumen = useMemo(() => {
    const totalXP = alumnos.reduce((acc, a) => acc + (a.puntos_acumulados || 0), 0)
    const completados = alumnos.filter((a) => a.bono_plan_otorgado).length
    const topAlumno = alumnos.length > 0 ? alumnos[0] : null
    return {
      totalAlumnos: alumnos.length,
      totalXP,
      completados,
      topAlumno,
    }
  }, [alumnos])

  const getCriterioIcon = (criterio: string) => {
    const c = criterio.toLowerCase()
    if (c.includes('asistencia')) return <CheckCircle2 className="w-4 h-4 text-emerald-500" />
    if (c.includes('puntualidad')) return <Calendar className="w-4 h-4 text-blue-500" />
    if (c.includes('plan')) return <Award className="w-4 h-4 text-amber-500" />
    if (c.includes('caloría')) return <Flame className="w-4 h-4 text-rose-500" />
    if (c.includes('corazón') || c.includes('cardíaca')) return <Zap className="w-4 h-4 text-red-500" />
    if (c.includes('constancia')) return <TrendingUp className="w-4 h-4 text-indigo-500" />
    if (c.includes('reto')) return <Trophy className="w-4 h-4 text-yellow-500" />
    if (c.includes('referido')) return <Gift className="w-4 h-4 text-purple-500" />
    return <Sparkles className="w-4 h-4 text-primary" />
  }

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12">
      {/* Encabezado */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-5">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-2xl font-black tracking-tight flex items-center gap-2">
              <Trophy className={`w-7 h-7 ${currentPalette.textClass}`} />
              <span>Gamificación y Progreso de {verticalConfig.clientePlural}</span>
            </h1>
            <Badge variant="outline" className="text-xs font-mono">
              {studioName}
            </Badge>
            <Badge variant="secondary" className="text-xs font-semibold">
              {verticalConfig.etiquetaNegocio}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Gestiona las reglas de puntos XP por esfuerzo y premia la constancia en el cumplimiento de los planes.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              cargarReglas()
              cargarAlumnos()
            }}
            disabled={loadingReglas || loadingAlumnos}
            className="h-9 text-xs gap-1.5"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${loadingReglas || loadingAlumnos ? 'animate-spin' : ''}`}
            />
            <span>Actualizar</span>
          </Button>
          <Button
            type="button"
            size="sm"
            onClick={handleOpenCrearRegla}
            className={`h-9 text-xs font-bold gap-1.5 ${currentPalette.bgClass} text-white`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>Nueva Regla XP</span>
          </Button>
        </div>
      </div>

      {/* Tarjetas de Métricas de Gamificación */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-border/80 shadow-xs">
          <CardContent className="p-4 space-y-1">
            <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              XP Totales Entregados
            </span>
            <div className="text-2xl font-black tracking-tight text-foreground">
              {metricasResumen.totalXP.toLocaleString()}
            </div>
            <p className="text-[11px] text-muted-foreground">Puntos acumulados en la sede</p>
          </CardContent>
        </Card>

        <Card className="border-border/80 shadow-xs">
          <CardContent className="p-4 space-y-1">
            <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-emerald-500" />
              Planes Cumplidos
            </span>
            <div className="text-2xl font-black tracking-tight text-foreground">
              {metricasResumen.completados}
            </div>
            <p className="text-[11px] text-muted-foreground">
              {metricasResumen.totalAlumnos > 0
                ? `${Math.round((metricasResumen.completados / metricasResumen.totalAlumnos) * 100)}% de los alumnos activos`
                : '0% de alumnos'}
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/80 shadow-xs">
          <CardContent className="p-4 space-y-1">
            <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
              <Trophy className="w-3.5 h-3.5 text-yellow-500" />
              Líder del Podio (#1)
            </span>
            <div className="text-base font-extrabold tracking-tight text-foreground truncate">
              {metricasResumen.topAlumno ? metricasResumen.topAlumno.nombre_completo : 'Sin datos'}
            </div>
            <p className="text-[11px] text-amber-600 dark:text-amber-400 font-bold">
              {metricasResumen.topAlumno
                ? `${metricasResumen.topAlumno.puntos_acumulados.toLocaleString()} XP (Nivel ${metricasResumen.topAlumno.nivel})`
                : '0 XP'}
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/80 shadow-xs">
          <CardContent className="p-4 space-y-1">
            <span className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-500" />
              Reglas Activas
            </span>
            <div className="text-2xl font-black tracking-tight text-foreground">
              {reglas.filter((r) => r.activo).length} / {reglas.length}
            </div>
            <p className="text-[11px] text-muted-foreground">Criterios de puntuación automáticos</p>
          </CardContent>
        </Card>
      </div>

      {/* SECCIÓN 1: REGLAS XP DEL ESTUDIO */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-500" />
              <span>Reglas de Puntuación XP del Estudio</span>
            </h2>
            <p className="text-xs text-muted-foreground">
              Configura los puntos otorgados por asistencia, puntualidad, superación del plan o hitos comerciales.
            </p>
          </div>
        </div>

        <Card className="border-border/80 shadow-xs overflow-hidden">
          <CardContent className="p-0">
            {loadingReglas ? (
              <div className="h-44 flex items-center justify-center">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : reglas.length === 0 ? (
              <div className="p-8 text-center text-xs text-muted-foreground space-y-2">
                <ShieldAlert className="w-8 h-8 mx-auto opacity-30 text-amber-500" />
                <p>No se encontraron reglas configuradas para este estudio.</p>
                <Button size="sm" variant="outline" onClick={handleOpenCrearRegla}>
                  Crear Primera Regla XP
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-border gap-px bg-border/40">
                {reglas.map((regla) => (
                  <div
                    key={regla.id}
                    className={`p-4 bg-card flex flex-col justify-between gap-3 transition-colors ${
                      !regla.activo ? 'opacity-60 bg-muted/20' : ''
                    }`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 rounded-md bg-secondary/80">
                            {getCriterioIcon(regla.criterio)}
                          </div>
                          <div>
                            <span className="font-extrabold text-xs text-foreground block">
                              {regla.criterio}
                            </span>
                            <span className="text-[10px] text-muted-foreground font-mono">
                              {regla.activo ? 'Activa' : 'Desactivada'}
                            </span>
                          </div>
                        </div>

                        <Badge
                          variant="secondary"
                          className="font-black font-mono text-xs px-2 py-0.5 bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20"
                        >
                          +{regla.puntos_xp} XP
                        </Badge>
                      </div>

                      {regla.descripcion && (
                        <p className="text-[11px] text-muted-foreground line-clamp-2 leading-relaxed">
                          {regla.descripcion}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center justify-between border-t pt-2.5 mt-auto">
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        disabled={togglingReglaId === regla.id}
                        onClick={() => handleToggleEstadoRegla(regla)}
                        className="h-7 px-2 text-[11px] gap-1"
                      >
                        {togglingReglaId === regla.id ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : regla.activo ? (
                          <XCircle className="w-3 h-3 text-amber-600" />
                        ) : (
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        )}
                        <span>{regla.activo ? 'Pausar' : 'Activar'}</span>
                      </Button>

                      <div className="flex items-center gap-1">
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={() => handleOpenEditarRegla(regla)}
                          className="h-7 w-7 p-0"
                          title="Editar regla"
                        >
                          <Pencil className="w-3 h-3 text-muted-foreground hover:text-foreground" />
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={() => setDeletingRegla(regla)}
                          className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                          title="Eliminar regla"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* SECCIÓN 2: PROGRESO DE PLANES Y RANKING DE ALUMNOS */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
              <Award className="w-5 h-5 text-emerald-500" />
              <span>Progreso de Planes y Ranking de {verticalConfig.clientePlural}</span>
            </h2>
            <p className="text-xs text-muted-foreground">
              Monitorea el cumplimiento de metas por plan de cada alumno, su porcentaje de avance y bonificaciones otorgadas.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder={`Buscar ${verticalConfig.clienteSingular.toLowerCase()}...`}
                value={busquedaAlumno}
                onChange={(e) => setBusquedaAlumno(e.target.value)}
                className="h-9 text-xs pl-8 font-sans"
              />
            </div>

            <div className="flex rounded-lg border border-border p-0.5 bg-muted/30">
              <button
                type="button"
                onClick={() => setFiltroPlanCumplido('todos')}
                className={`text-[11px] font-bold px-2.5 py-1 rounded-md transition-colors ${
                  filtroPlanCumplido === 'todos' ? 'bg-background shadow-xs text-foreground' : 'text-muted-foreground'
                }`}
              >
                Todos ({alumnos.length})
              </button>
              <button
                type="button"
                onClick={() => setFiltroPlanCumplido('cumplido')}
                className={`text-[11px] font-bold px-2.5 py-1 rounded-md transition-colors ${
                  filtroPlanCumplido === 'cumplido' ? 'bg-background shadow-xs text-emerald-600' : 'text-muted-foreground'
                }`}
              >
                Plan 100% ({alumnos.filter((a) => a.bono_plan_otorgado).length})
              </button>
              <button
                type="button"
                onClick={() => setFiltroPlanCumplido('en_progreso')}
                className={`text-[11px] font-bold px-2.5 py-1 rounded-md transition-colors ${
                  filtroPlanCumplido === 'en_progreso' ? 'bg-background shadow-xs text-blue-600' : 'text-muted-foreground'
                }`}
              >
                En Progreso
              </button>
            </div>
          </div>
        </div>

        <Card className="border-border/80 shadow-xs overflow-hidden">
          <CardContent className="p-0">
            {loadingAlumnos ? (
              <div className="h-56 flex items-center justify-center">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : alumnosFiltrados.length === 0 ? (
              <div className="p-10 text-center text-xs text-muted-foreground space-y-2">
                <Award className="w-8 h-8 mx-auto opacity-30 text-emerald-500" />
                <p>No se encontraron alumnos con los filtros seleccionados.</p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {alumnosFiltrados.map((alumno) => {
                  const esTop1 = alumno.ranking === 1
                  const esTop2 = alumno.ranking === 2
                  const esTop3 = alumno.ranking === 3

                  return (
                    <div
                      key={alumno.usuario_id}
                      className="p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-muted/10 transition-colors"
                    >
                      {/* Información del Alumno */}
                      <div className="flex items-center gap-3 min-w-0">
                        {/* Indicador de Ranking */}
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs shrink-0 ${
                            esTop1
                              ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20 ring-2 ring-amber-300'
                              : esTop2
                              ? 'bg-slate-300 text-slate-800'
                              : esTop3
                              ? 'bg-amber-700 text-white'
                              : 'bg-secondary text-muted-foreground'
                          }`}
                        >
                          {esTop1 ? '🥇' : esTop2 ? '🥈' : esTop3 ? '🥉' : `#${alumno.ranking}`}
                        </div>

                        {/* Avatar */}
                        {alumno.avatar_url ? (
                          <img
                            src={alumno.avatar_url}
                            alt={alumno.nombre_completo}
                            className="w-10 h-10 rounded-full object-cover border shrink-0"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm shrink-0 border">
                            {alumno.nombre_completo.charAt(0).toUpperCase()}
                          </div>
                        )}

                        <div className="min-w-0 space-y-0.5">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-extrabold text-sm text-foreground truncate">
                              {alumno.nombre_completo}
                            </span>
                            <Badge
                              variant="secondary"
                              className="text-[10px] font-bold bg-purple-500/10 text-purple-700 dark:text-purple-300 border border-purple-500/20"
                            >
                              Nivel {alumno.nivel}
                            </Badge>
                            {alumno.bono_plan_otorgado && (
                              <Badge
                                variant="secondary"
                                className="text-[10px] font-black bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 gap-1"
                              >
                                <Award className="w-3 h-3 text-emerald-600" />
                                Plan Cumplido (+150 XP)
                              </Badge>
                            )}
                          </div>

                          <div className="text-xs text-muted-foreground flex flex-wrap items-center gap-3">
                            <span>{alumno.email}</span>
                            {alumno.codigo_qr && (
                              <span className="font-mono text-[10px] bg-muted px-1.5 py-0.5 rounded">
                                {alumno.codigo_qr}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Progreso del Plan y Puntuación XP */}
                      <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-6 shrink-0 md:min-w-[360px] justify-end">
                        {/* Barra de Progreso del Plan */}
                        <div className="space-y-1.5 flex-1 max-w-[220px]">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-foreground flex items-center gap-1">
                              <span>Progreso Plan:</span>
                              <span className="text-muted-foreground font-normal">
                                {alumno.dias_cumplidos} / {alumno.dias_programados || '–'}{' '}
                                {verticalConfig.sesionPlural.toLowerCase()}
                              </span>
                            </span>
                            <span className="font-mono font-extrabold text-[11px] text-foreground">
                              {alumno.porcentaje}%
                            </span>
                          </div>

                          <div className="w-full bg-secondary rounded-full h-2 overflow-hidden">
                            <div
                              className={`h-full transition-all duration-300 rounded-full ${
                                alumno.porcentaje >= 100
                                  ? 'bg-emerald-500'
                                  : alumno.porcentaje >= 50
                                  ? 'bg-blue-500'
                                  : 'bg-primary'
                              }`}
                              style={{ width: `${Math.min(100, alumno.porcentaje)}%` }}
                            />
                          </div>
                        </div>

                        {/* XP Acumulados */}
                        <div className="text-right shrink-0">
                          <div className="flex items-center justify-end gap-1 font-mono font-black text-sm text-foreground">
                            <Zap className="w-4 h-4 text-amber-500" />
                            <span>{alumno.puntos_acumulados.toLocaleString()} XP</span>
                          </div>
                          <span className="text-[10px] text-muted-foreground">Puntos de maestría</span>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* MODAL CREAR / EDITAR REGLA XP */}
      {modalReglaOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <Card className="w-full max-w-md shadow-2xl border-border bg-card overflow-hidden">
            <CardHeader className="p-5 pb-3 border-b">
              <div className="flex justify-between items-center">
                <CardTitle className="text-base flex items-center gap-2">
                  <Zap className={`w-4 h-4 ${currentPalette.textClass}`} />
                  {editingRegla ? 'Editar Regla de Puntuación XP' : 'Nueva Regla XP del Estudio'}
                </CardTitle>
                <button
                  type="button"
                  onClick={() => setModalReglaOpen(false)}
                  className="text-muted-foreground hover:text-foreground text-sm font-bold"
                >
                  ✕
                </button>
              </div>
              <CardDescription className="text-xs">
                Define el criterio y la cantidad de puntos XP que se acreditarán automáticamente.
              </CardDescription>
            </CardHeader>

            <form onSubmit={handleGuardarRegla}>
              <CardContent className="p-5 space-y-3.5 text-xs">
                <div className="space-y-1">
                  <label className="font-bold text-foreground">Criterio o Evento</label>
                  <Input
                    required
                    placeholder="Ej: Asistencia, Puntualidad, Reto Semanal..."
                    value={formRegla.criterio}
                    onChange={(e) => setFormRegla({ ...formRegla, criterio: e.target.value })}
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-foreground">Puntos XP Otorgados</label>
                  <Input
                    type="number"
                    min={0}
                    step={5}
                    required
                    placeholder="100"
                    value={formRegla.puntosXp}
                    onChange={(e) => setFormRegla({ ...formRegla, puntosXp: e.target.value })}
                  />
                  <p className="text-[10px] text-muted-foreground">
                    Cada 300 XP el alumno sube 1 nivel de maestría.
                  </p>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-foreground">Descripción del Hito</label>
                  <Input
                    placeholder="Ej: Se otorga al validar el ingreso en el control de asistencia..."
                    value={formRegla.descripcion}
                    onChange={(e) => setFormRegla({ ...formRegla, descripcion: e.target.value })}
                  />
                </div>

                <label className="flex items-center gap-2 pt-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formRegla.activo}
                    onChange={(e) => setFormRegla({ ...formRegla, activo: e.target.checked })}
                    className="rounded border-input"
                  />
                  <span className="font-semibold text-foreground">Regla activa en el cálculo automático</span>
                </label>
              </CardContent>

              <div className="p-5 pt-0 border-t flex items-center justify-end gap-2 mt-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setModalReglaOpen(false)}
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  size="sm"
                  disabled={guardandoRegla}
                  className={`font-bold ${currentPalette.bgClass} text-white`}
                >
                  {guardandoRegla ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" />
                      Guardando...
                    </>
                  ) : editingRegla ? (
                    'Guardar Cambios'
                  ) : (
                    'Crear Regla XP'
                  )}
                </Button>
              </div>
            </form>
          </Card>
        </div>
      )}

      {/* MODAL CONFIRMAR ELIMINACIÓN REGLA */}
      {deletingRegla && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <Card className="w-full max-w-sm shadow-2xl border-border bg-card overflow-hidden">
            <CardHeader className="p-5 pb-3 border-b">
              <CardTitle className="text-base text-destructive">Eliminar Regla XP</CardTitle>
              <CardDescription className="text-xs">
                ¿Estás seguro de eliminar la regla <strong>{deletingRegla.criterio}</strong>? Los puntos ya otorgados a los alumnos no se verán afectados.
              </CardDescription>
            </CardHeader>
            <div className="p-5 flex items-center justify-end gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={eliminandoRegla}
                onClick={() => setDeletingRegla(null)}
              >
                Cancelar
              </Button>
              <Button
                type="button"
                variant="destructive"
                size="sm"
                disabled={eliminandoRegla}
                onClick={handleConfirmEliminarRegla}
              >
                {eliminandoRegla ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" /> : null}
                Eliminar
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}

export default GamificacionAdminView
